#!/bin/bash
filename="data/208.json"
search="https://badass-site.000webhostapp.com/nft_images/"
replace='https://badass-site.000webhostapp.com/nft_images/'
dir="data"
for entry in `ls ./$data`/*;
do
  if [[ $search != "" && $replace != "" ]]; then
    sed -i'.bac' "s/${search//\//\/}/${replace//\//\/}/g" $entry
  fi
done
